package aa.car;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;
    public static boolean dontPause;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "aa.car", "aa.car.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "aa.car", "aa.car.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "aa.car.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        if (!dontPause)
            BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        else
            BA.LogInfo("** Activity (main) Pause event (activity is not paused). **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        if (!dontPause) {
            processBA.setActivityPaused(true);
            mostCurrent = null;
        }

        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.RuntimePermissions _rp = null;
public static String _str = "";
public aa.car.bluetoothasynchstream _bta = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _tbtled = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblstatus = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnconnect = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblmessage = null;
public anywheresoftware.b4a.objects.ProgressBarWrapper _progressbar1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label1 = null;
public aa.car.clxtoastmessage1 _tm = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button3 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button4 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button0 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button5 = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel1 = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel2 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsearchfordevices = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnclose = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview1 = null;
public aa.car.starter _starter = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static class _mymessage{
public boolean IsInitialized;
public String Name;
public String str;
public void Initialize() {
IsInitialized = true;
Name = "";
str = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _twostrings{
public boolean IsInitialized;
public String a;
public String b;
public void Initialize() {
IsInitialized = true;
a = "";
b = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _btdevice{
public boolean IsInitialized;
public String Name;
public String Mac;
public void Initialize() {
IsInitialized = true;
Name = "";
Mac = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 54;BA.debugLine="Activity.LoadLayout(\"Main\")";
mostCurrent._activity.LoadLayout("Main",mostCurrent.activityBA);
 //BA.debugLineNum = 57;BA.debugLine="Panel1.Top =0dip";
mostCurrent._panel1.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 58;BA.debugLine="Panel1.Left =0dip";
mostCurrent._panel1.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 59;BA.debugLine="Panel1.Height =Activity.Height";
mostCurrent._panel1.setHeight(mostCurrent._activity.getHeight());
 //BA.debugLineNum = 60;BA.debugLine="Panel1.Width =100%y";
mostCurrent._panel1.setWidth(anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (100),mostCurrent.activityBA));
 //BA.debugLineNum = 62;BA.debugLine="Panel2.Top =0dip";
mostCurrent._panel2.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 63;BA.debugLine="Panel2.Left =0dip";
mostCurrent._panel2.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 64;BA.debugLine="Panel2.Height =Activity.Height";
mostCurrent._panel2.setHeight(mostCurrent._activity.getHeight());
 //BA.debugLineNum = 65;BA.debugLine="Panel2.Width =100%y";
mostCurrent._panel2.setWidth(anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (100),mostCurrent.activityBA));
 //BA.debugLineNum = 67;BA.debugLine="Panel1.Visible =True";
mostCurrent._panel1.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 68;BA.debugLine="Panel2.Visible =False";
mostCurrent._panel2.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 71;BA.debugLine="BTA.Initialize(Me, \"BT\", lblStatus ) '???";
mostCurrent._bta._initialize /*String*/ (mostCurrent.activityBA,main.getObject(),"BT",mostCurrent._lblstatus);
 //BA.debugLineNum = 72;BA.debugLine="tm.Initialize(Activity)";
mostCurrent._tm._initialize /*String*/ (mostCurrent.activityBA,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(mostCurrent._activity.getObject())));
 //BA.debugLineNum = 73;BA.debugLine="str=\"0\"";
_str = "0";
 //BA.debugLineNum = 75;BA.debugLine="SetState";
_setstate();
 //BA.debugLineNum = 76;BA.debugLine="Log(\"app start\")";
anywheresoftware.b4a.keywords.Common.LogImpl("5131095","app start",0);
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 84;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 85;BA.debugLine="If UserClosed = True And BTA.connected = True The";
if (_userclosed==anywheresoftware.b4a.keywords.Common.True && mostCurrent._bta._connected /*boolean*/ ==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 87;BA.debugLine="BTA.SendBytes(\"0\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("0".getBytes("UTF8"));
 //BA.debugLineNum = 88;BA.debugLine="BTA.Close";
mostCurrent._bta._close /*String*/ ();
 };
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.drawable.ColorDrawable  _background(int _color) throws Exception{
anywheresoftware.b4a.objects.drawable.ColorDrawable _cdb = null;
 //BA.debugLineNum = 205;BA.debugLine="Sub BackGround(Color As Int) As ColorDrawable";
 //BA.debugLineNum = 206;BA.debugLine="Dim cdb As ColorDrawable";
_cdb = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 208;BA.debugLine="cdb.Initialize(Color, 5dip)";
_cdb.Initialize(_color,anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)));
 //BA.debugLineNum = 209;BA.debugLine="Return cdb";
if (true) return _cdb;
 //BA.debugLineNum = 210;BA.debugLine="End Sub";
return null;
}
public static String  _bt_newtext(String _msg) throws Exception{
 //BA.debugLineNum = 138;BA.debugLine="Public Sub BT_NewText(msg As String)";
 //BA.debugLineNum = 141;BA.debugLine="lblMessage.Text=msg.SubString2(0,1)";
mostCurrent._lblmessage.setText(BA.ObjectToCharSequence(_msg.substring((int) (0),(int) (1))));
 //BA.debugLineNum = 142;BA.debugLine="str=msg.SubString2(0,1)";
_str = _msg.substring((int) (0),(int) (1));
 //BA.debugLineNum = 143;BA.debugLine="If msg.SubString2(0,1) == \"0\" Then";
if ((_msg.substring((int) (0),(int) (1))).equals("0")) { 
 //BA.debugLineNum = 144;BA.debugLine="tbtLED.Checked = True";
mostCurrent._tbtled.setChecked(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 146;BA.debugLine="Button0.Text=\"開\"";
mostCurrent._button0.setText(BA.ObjectToCharSequence("開"));
 //BA.debugLineNum = 147;BA.debugLine="Button0.Background = BackGround(Colors.Red)";
mostCurrent._button0.setBackground((android.graphics.drawable.Drawable)(_background(anywheresoftware.b4a.keywords.Common.Colors.Red).getObject()));
 }else {
 //BA.debugLineNum = 151;BA.debugLine="tbtLED.Checked = False";
mostCurrent._tbtled.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 153;BA.debugLine="Button0.Text=\"關\"";
mostCurrent._button0.setText(BA.ObjectToCharSequence("關"));
 //BA.debugLineNum = 154;BA.debugLine="Button0.Background = BackGround(Colors.White)";
mostCurrent._button0.setBackground((android.graphics.drawable.Drawable)(_background(anywheresoftware.b4a.keywords.Common.Colors.White).getObject()));
 };
 //BA.debugLineNum = 159;BA.debugLine="End Sub";
return "";
}
public static String  _btnclose_click() throws Exception{
 //BA.debugLineNum = 291;BA.debugLine="Private Sub btnClose_Click";
 //BA.debugLineNum = 293;BA.debugLine="Panel1.Visible =True";
mostCurrent._panel1.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 294;BA.debugLine="Panel2.Visible =False";
mostCurrent._panel2.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 297;BA.debugLine="End Sub";
return "";
}
public static String  _btnconnect_click() throws Exception{
aa.car.csvparser _parser = null;
anywheresoftware.b4a.objects.collections.List _table = null;
String[] _row = null;
aa.car.main._btdevice _b = null;
 //BA.debugLineNum = 94;BA.debugLine="Sub btnConnect_Click";
 //BA.debugLineNum = 96;BA.debugLine="Log(\"btnConnect_Click\")";
anywheresoftware.b4a.keywords.Common.LogImpl("5327682","btnConnect_Click",0);
 //BA.debugLineNum = 98;BA.debugLine="Panel1.Visible =False";
mostCurrent._panel1.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 99;BA.debugLine="Panel2.Visible =True";
mostCurrent._panel2.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 101;BA.debugLine="ListView1.Top =5dip";
mostCurrent._listview1.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)));
 //BA.debugLineNum = 102;BA.debugLine="ListView1.Left =5dip";
mostCurrent._listview1.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)));
 //BA.debugLineNum = 104;BA.debugLine="ListView1.Width =Activity.width -10dip";
mostCurrent._listview1.setWidth((int) (mostCurrent._activity.getWidth()-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10))));
 //BA.debugLineNum = 106;BA.debugLine="btnSearchForDevices.Left =5dip";
mostCurrent._btnsearchfordevices.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)));
 //BA.debugLineNum = 107;BA.debugLine="btnSearchForDevices.Width =Activity.width -10dip";
mostCurrent._btnsearchfordevices.setWidth((int) (mostCurrent._activity.getWidth()-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10))));
 //BA.debugLineNum = 108;BA.debugLine="btnClose.Left =5dip";
mostCurrent._btnclose.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (5)));
 //BA.debugLineNum = 109;BA.debugLine="btnClose.Width =Activity.width -10dip";
mostCurrent._btnclose.setWidth((int) (mostCurrent._activity.getWidth()-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (10))));
 //BA.debugLineNum = 111;BA.debugLine="ListView1.Clear";
mostCurrent._listview1.Clear();
 //BA.debugLineNum = 112;BA.debugLine="If File.Exists(File.DirDefaultExternal, \"Devices.";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"Devices.csv")) { 
 //BA.debugLineNum = 114;BA.debugLine="Dim parser As CSVParser";
_parser = new aa.car.csvparser();
 //BA.debugLineNum = 115;BA.debugLine="parser.Initialize";
_parser._initialize /*String*/ (processBA);
 //BA.debugLineNum = 116;BA.debugLine="Dim table As List = parser.Parse(File.ReadString";
_table = new anywheresoftware.b4a.objects.collections.List();
_table = _parser._parse /*anywheresoftware.b4a.objects.collections.List*/ (anywheresoftware.b4a.keywords.Common.File.ReadString(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"Devices.csv"),",",anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 119;BA.debugLine="For Each row() As String In table";
{
final anywheresoftware.b4a.BA.IterableList group16 = _table;
final int groupLen16 = group16.getSize()
;int index16 = 0;
;
for (; index16 < groupLen16;index16++){
_row = (String[])(group16.Get(index16));
 //BA.debugLineNum = 121;BA.debugLine="Dim b As BTDevice";
_b = new aa.car.main._btdevice();
 //BA.debugLineNum = 123;BA.debugLine="b.Initialize";
_b.Initialize();
 //BA.debugLineNum = 124;BA.debugLine="b.Name=row(0)";
_b.Name /*String*/  = _row[(int) (0)];
 //BA.debugLineNum = 125;BA.debugLine="b.Mac=row(1)";
_b.Mac /*String*/  = _row[(int) (1)];
 //BA.debugLineNum = 127;BA.debugLine="ListView1.AddTwoLines2(b.name, b.mac,b)";
mostCurrent._listview1.AddTwoLines2(BA.ObjectToCharSequence(_b.Name /*String*/ ),BA.ObjectToCharSequence(_b.Mac /*String*/ ),(Object)(_b));
 }
};
 };
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public static void  _btnsearchfordevices_click() throws Exception{
ResumableSub_btnSearchForDevices_Click rsub = new ResumableSub_btnSearchForDevices_Click(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_btnSearchForDevices_Click extends BA.ResumableSub {
public ResumableSub_btnSearchForDevices_Click(aa.car.main parent) {
this.parent = parent;
}
aa.car.main parent;
String _permission = "";
boolean _result = false;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 262;BA.debugLine="rp.CheckAndRequest(rp.PERMISSION_WRITE_EXTERNAL_S";
parent._rp.CheckAndRequest(processBA,parent._rp.PERMISSION_WRITE_EXTERNAL_STORAGE);
 //BA.debugLineNum = 263;BA.debugLine="Wait For Activity_PermissionResult (Permission As";
anywheresoftware.b4a.keywords.Common.WaitFor("activity_permissionresult", processBA, this, null);
this.state = 19;
return;
case 19:
//C
this.state = 1;
_permission = (String) result[0];
_result = (Boolean) result[1];
;
 //BA.debugLineNum = 264;BA.debugLine="If Result = False Then";
if (true) break;

case 1:
//if
this.state = 18;
if (_result==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 18;
 //BA.debugLineNum = 265;BA.debugLine="ToastMessageShow(\"PERMISSION_WRITE_EXTERNAL_STOR";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("PERMISSION_WRITE_EXTERNAL_STORAGE  無權限"),anywheresoftware.b4a.keywords.Common.True);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 272;BA.debugLine="rp.CheckAndRequest(rp.PERMISSION_ACCESS_FINE_LOC";
parent._rp.CheckAndRequest(processBA,parent._rp.PERMISSION_ACCESS_FINE_LOCATION);
 //BA.debugLineNum = 273;BA.debugLine="Wait For Activity_PermissionResult (Permission A";
anywheresoftware.b4a.keywords.Common.WaitFor("activity_permissionresult", processBA, this, null);
this.state = 20;
return;
case 20:
//C
this.state = 6;
_permission = (String) result[0];
_result = (Boolean) result[1];
;
 //BA.debugLineNum = 274;BA.debugLine="If Result = False Then";
if (true) break;

case 6:
//if
this.state = 17;
if (_result==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 8;
}else {
this.state = 10;
}if (true) break;

case 8:
//C
this.state = 17;
 //BA.debugLineNum = 275;BA.debugLine="lblStatus.Text = \"無權限(藍芽)...\"";
parent.mostCurrent._lblstatus.setText(BA.ObjectToCharSequence("無權限(藍芽)..."));
 if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 278;BA.debugLine="Dim success As Boolean = BTA.SearchForDevices";
_success = parent.mostCurrent._bta._searchfordevices /*boolean*/ ();
 //BA.debugLineNum = 279;BA.debugLine="If success = False Then";
if (true) break;

case 11:
//if
this.state = 16;
if (_success==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 13;
}else {
this.state = 15;
}if (true) break;

case 13:
//C
this.state = 16;
 //BA.debugLineNum = 280;BA.debugLine="ToastMessageShow(\"Error starting discovery pro";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error starting discovery process."),anywheresoftware.b4a.keywords.Common.True);
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 282;BA.debugLine="ProgressDialogShow2(\"找尋藍芽設備中...\", False)";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow2(mostCurrent.activityBA,BA.ObjectToCharSequence("找尋藍芽設備中..."),anywheresoftware.b4a.keywords.Common.False);
 if (true) break;

case 16:
//C
this.state = 17;
;
 if (true) break;

case 17:
//C
this.state = 18;
;
 if (true) break;

case 18:
//C
this.state = -1;
;
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _activity_permissionresult(String _permission,boolean _result) throws Exception{
}
public static String  _button0_click() throws Exception{
 //BA.debugLineNum = 235;BA.debugLine="Private Sub Button0_Click";
 //BA.debugLineNum = 237;BA.debugLine="If str.SubString2(0,1) == \"0\" Then";
if ((_str.substring((int) (0),(int) (1))).equals("0")) { 
 //BA.debugLineNum = 238;BA.debugLine="str= \"1\"";
_str = "1";
 //BA.debugLineNum = 240;BA.debugLine="BTA.SendBytes( \"1\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("1".getBytes("UTF8"));
 //BA.debugLineNum = 242;BA.debugLine="Button0.Text=\"關\"";
mostCurrent._button0.setText(BA.ObjectToCharSequence("關"));
 //BA.debugLineNum = 243;BA.debugLine="Button0.Background = BackGround(Colors.White)";
mostCurrent._button0.setBackground((android.graphics.drawable.Drawable)(_background(anywheresoftware.b4a.keywords.Common.Colors.White).getObject()));
 }else {
 //BA.debugLineNum = 247;BA.debugLine="str= \"0\"";
_str = "0";
 //BA.debugLineNum = 249;BA.debugLine="BTA.SendBytes(\"0\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("0".getBytes("UTF8"));
 //BA.debugLineNum = 251;BA.debugLine="Button0.Text=\"開\"";
mostCurrent._button0.setText(BA.ObjectToCharSequence("開"));
 //BA.debugLineNum = 252;BA.debugLine="Button0.Background = BackGround(Colors.Red)";
mostCurrent._button0.setBackground((android.graphics.drawable.Drawable)(_background(anywheresoftware.b4a.keywords.Common.Colors.Red).getObject()));
 };
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 214;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 215;BA.debugLine="BTA.SendBytes( \"w\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("w".getBytes("UTF8"));
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
return "";
}
public static String  _button2_click() throws Exception{
 //BA.debugLineNum = 218;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 219;BA.debugLine="BTA.SendBytes( \"x\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("x".getBytes("UTF8"));
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public static String  _button3_click() throws Exception{
 //BA.debugLineNum = 222;BA.debugLine="Private Sub Button3_Click";
 //BA.debugLineNum = 223;BA.debugLine="BTA.SendBytes( \"a\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("a".getBytes("UTF8"));
 //BA.debugLineNum = 224;BA.debugLine="End Sub";
return "";
}
public static String  _button4_click() throws Exception{
 //BA.debugLineNum = 226;BA.debugLine="Private Sub Button4_Click";
 //BA.debugLineNum = 227;BA.debugLine="BTA.SendBytes( \"d\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("d".getBytes("UTF8"));
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return "";
}
public static String  _button5_click() throws Exception{
 //BA.debugLineNum = 230;BA.debugLine="Private Sub Button5_Click";
 //BA.debugLineNum = 231;BA.debugLine="BTA.SendBytes( \"s\".GetBytes(\"UTF8\"))";
mostCurrent._bta._sendbytes /*String*/ ("s".getBytes("UTF8"));
 //BA.debugLineNum = 232;BA.debugLine="End Sub";
return "";
}
public static String  _connectok() throws Exception{
 //BA.debugLineNum = 359;BA.debugLine="Public Sub ConnectOK";
 //BA.debugLineNum = 361;BA.debugLine="Panel1.Visible =True";
mostCurrent._panel1.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 362;BA.debugLine="Panel2.Visible =False";
mostCurrent._panel2.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return "";
}
public static String  _discoverfinished() throws Exception{
aa.car.csvparser _parser = null;
anywheresoftware.b4a.objects.collections.List _list1 = null;
aa.car.bluetoothasynchstream._nameandmac _nm = null;
aa.car.main._btdevice _b = null;
String _s = "";
 //BA.debugLineNum = 301;BA.debugLine="Public Sub DiscoverFinished";
 //BA.debugLineNum = 304;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 305;BA.debugLine="If BTA.foundDevices.Size = 0 Then";
if (mostCurrent._bta._founddevices /*anywheresoftware.b4a.objects.collections.List*/ .getSize()==0) { 
 //BA.debugLineNum = 306;BA.debugLine="ToastMessageShow(\"沒有可用的藍芽設備.\", True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("沒有可用的藍芽設備."),anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 309;BA.debugLine="Dim parser As CSVParser";
_parser = new aa.car.csvparser();
 //BA.debugLineNum = 310;BA.debugLine="parser.Initialize";
_parser._initialize /*String*/ (processBA);
 //BA.debugLineNum = 311;BA.debugLine="Dim List1 As List";
_list1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 312;BA.debugLine="List1.Initialize";
_list1.Initialize();
 //BA.debugLineNum = 314;BA.debugLine="ListView1.Clear";
mostCurrent._listview1.Clear();
 //BA.debugLineNum = 315;BA.debugLine="For Each nm As NameAndMac In BTA.foundDevices";
{
final anywheresoftware.b4a.BA.IterableList group10 = mostCurrent._bta._founddevices /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen10 = group10.getSize()
;int index10 = 0;
;
for (; index10 < groupLen10;index10++){
_nm = (aa.car.bluetoothasynchstream._nameandmac)(group10.Get(index10));
 //BA.debugLineNum = 317;BA.debugLine="Dim b As BTDevice";
_b = new aa.car.main._btdevice();
 //BA.debugLineNum = 319;BA.debugLine="b.Initialize";
_b.Initialize();
 //BA.debugLineNum = 320;BA.debugLine="b.Name=nm.name";
_b.Name /*String*/  = _nm.Name /*String*/ ;
 //BA.debugLineNum = 321;BA.debugLine="b.Mac=nm.mac";
_b.Mac /*String*/  = _nm.Mac /*String*/ ;
 //BA.debugLineNum = 323;BA.debugLine="ListView1.AddTwoLines2(b.name, b.mac,b)";
mostCurrent._listview1.AddTwoLines2(BA.ObjectToCharSequence(_b.Name /*String*/ ),BA.ObjectToCharSequence(_b.Mac /*String*/ ),(Object)(_b));
 //BA.debugLineNum = 327;BA.debugLine="List1.Add(Array As String(nm.Name, nm.Mac))";
_list1.Add((Object)(new String[]{_nm.Name /*String*/ ,_nm.Mac /*String*/ }));
 }
};
 //BA.debugLineNum = 332;BA.debugLine="Dim s As String = parser.GenerateString(List1, \"";
_s = _parser._generatestring /*String*/ (_list1,",");
 //BA.debugLineNum = 333;BA.debugLine="File.WriteString(File.DirDefaultExternal, \"Devic";
anywheresoftware.b4a.keywords.Common.File.WriteString(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"Devices.csv",_s);
 };
 //BA.debugLineNum = 356;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 28;BA.debugLine="Private BTA As BluetoothAsynchStream";
mostCurrent._bta = new aa.car.bluetoothasynchstream();
 //BA.debugLineNum = 29;BA.debugLine="Private tbtLED As ToggleButton";
mostCurrent._tbtled = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private lblStatus As Label";
mostCurrent._lblstatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private btnConnect As Button";
mostCurrent._btnconnect = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private lblMessage As Label";
mostCurrent._lblmessage = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private ProgressBar1 As ProgressBar";
mostCurrent._progressbar1 = new anywheresoftware.b4a.objects.ProgressBarWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private Button1 As Button";
mostCurrent._button1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private Label1 As Label";
mostCurrent._label1 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private tm As clXToastMessage1";
mostCurrent._tm = new aa.car.clxtoastmessage1();
 //BA.debugLineNum = 40;BA.debugLine="Private Button2 As Button";
mostCurrent._button2 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private Button3 As Button";
mostCurrent._button3 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private Button4 As Button";
mostCurrent._button4 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private Button0 As Button";
mostCurrent._button0 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private Button5 As Button";
mostCurrent._button5 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private Panel1 As Panel";
mostCurrent._panel1 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private Panel2 As Panel";
mostCurrent._panel2 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 48;BA.debugLine="Private btnSearchForDevices As Button";
mostCurrent._btnsearchfordevices = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private btnClose As Button";
mostCurrent._btnclose = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 50;BA.debugLine="Private ListView1 As ListView";
mostCurrent._listview1 = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public static String  _listview1_itemclick(int _position,Object _value) throws Exception{
aa.car.main._btdevice _b = null;
aa.car.bluetoothasynchstream._nameandmac _device = null;
 //BA.debugLineNum = 367;BA.debugLine="Private Sub ListView1_ItemClick (Position As Int,";
 //BA.debugLineNum = 370;BA.debugLine="Dim b As BTDevice";
_b = new aa.car.main._btdevice();
 //BA.debugLineNum = 371;BA.debugLine="b.Initialize";
_b.Initialize();
 //BA.debugLineNum = 372;BA.debugLine="b=Value";
_b = (aa.car.main._btdevice)(_value);
 //BA.debugLineNum = 373;BA.debugLine="Log(\"ListView1_ItemClick ==> \" & b.Name)";
anywheresoftware.b4a.keywords.Common.LogImpl("53866630","ListView1_ItemClick ==> "+_b.Name /*String*/ ,0);
 //BA.debugLineNum = 375;BA.debugLine="Dim device As NameAndMac";
_device = new aa.car.bluetoothasynchstream._nameandmac();
 //BA.debugLineNum = 377;BA.debugLine="device.Name =b.Name";
_device.Name /*String*/  = _b.Name /*String*/ ;
 //BA.debugLineNum = 378;BA.debugLine="device.Mac =b.Mac";
_device.Mac /*String*/  = _b.Mac /*String*/ ;
 //BA.debugLineNum = 379;BA.debugLine="BTA.ConnectTo( device )";
mostCurrent._bta._connectto /*String*/ (_device);
 //BA.debugLineNum = 380;BA.debugLine="ProgressDialogShow2($\"正在連線: ${device.Name} (${dev";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow2(mostCurrent.activityBA,BA.ObjectToCharSequence(("正在連線: "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_device.Name /*String*/ ))+" ("+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_device.Mac /*String*/ ))+")")),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 387;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
starter._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 18;BA.debugLine="Private rp As RuntimePermissions";
_rp = new anywheresoftware.b4a.objects.RuntimePermissions();
 //BA.debugLineNum = 20;BA.debugLine="Type MyMessage (Name As String, str As String)";
;
 //BA.debugLineNum = 21;BA.debugLine="Type twostrings (a As String , b As String)";
;
 //BA.debugLineNum = 22;BA.debugLine="Type BTDevice (Name As String, Mac As String)";
;
 //BA.debugLineNum = 23;BA.debugLine="Dim str As String";
_str = "";
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public static String  _setstate() throws Exception{
 //BA.debugLineNum = 164;BA.debugLine="Public Sub SetState";
 //BA.debugLineNum = 166;BA.debugLine="If  BTA.connected Then";
if (mostCurrent._bta._connected /*boolean*/ ) { 
 //BA.debugLineNum = 167;BA.debugLine="btnConnect.Text = \"離線\"";
mostCurrent._btnconnect.setText(BA.ObjectToCharSequence("離線"));
 //BA.debugLineNum = 168;BA.debugLine="lblStatus.Text = \"連線中\"";
mostCurrent._lblstatus.setText(BA.ObjectToCharSequence("連線中"));
 //BA.debugLineNum = 170;BA.debugLine="btnConnect.Enabled = False";
mostCurrent._btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 171;BA.debugLine="tbtLED.Enabled = True";
mostCurrent._tbtled.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 173;BA.debugLine="Button0.Enabled  = True";
mostCurrent._button0.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 174;BA.debugLine="Button1.Enabled  = True";
mostCurrent._button1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 175;BA.debugLine="Button2.Enabled  = True";
mostCurrent._button2.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 176;BA.debugLine="Button3.Enabled  = True";
mostCurrent._button3.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 177;BA.debugLine="Button4.Enabled  = True";
mostCurrent._button4.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 178;BA.debugLine="Button5.Enabled  = True";
mostCurrent._button5.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 181;BA.debugLine="btnConnect.Text = \"開始連\"";
mostCurrent._btnconnect.setText(BA.ObjectToCharSequence("開始連"));
 //BA.debugLineNum = 182;BA.debugLine="lblStatus.Text = \"離線\"";
mostCurrent._lblstatus.setText(BA.ObjectToCharSequence("離線"));
 //BA.debugLineNum = 184;BA.debugLine="btnConnect.Enabled = True";
mostCurrent._btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 185;BA.debugLine="tbtLED.Enabled = False";
mostCurrent._tbtled.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 187;BA.debugLine="Button0.Enabled  = False";
mostCurrent._button0.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 188;BA.debugLine="Button1.Enabled  = False";
mostCurrent._button1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 189;BA.debugLine="Button2.Enabled  = False";
mostCurrent._button2.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 190;BA.debugLine="Button3.Enabled  = False";
mostCurrent._button3.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 191;BA.debugLine="Button4.Enabled  = False";
mostCurrent._button4.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 192;BA.debugLine="Button5.Enabled  = False";
mostCurrent._button5.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return "";
}
public static String  _updatelabel1(String _msg) throws Exception{
 //BA.debugLineNum = 199;BA.debugLine="Public Sub UpdateLabel1(msg As String)";
 //BA.debugLineNum = 201;BA.debugLine="Label1.Text=msg";
mostCurrent._label1.setText(BA.ObjectToCharSequence(_msg));
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
}
